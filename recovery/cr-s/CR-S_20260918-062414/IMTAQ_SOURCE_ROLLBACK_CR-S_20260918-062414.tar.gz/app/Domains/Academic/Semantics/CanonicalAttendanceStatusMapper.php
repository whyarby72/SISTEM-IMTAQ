<?php

namespace App\Domains\Academic\Semantics;

use App\Domains\Academic\Semantics\Enums\CanonicalAttendanceStatus;

final class CanonicalAttendanceStatusMapper
{
    public function map(?string $status): ?CanonicalAttendanceStatus
    {
        return match ($status) {
            null => null,
            'PRESENT' => CanonicalAttendanceStatus::PRESENT,
            'IZIN', 'PERMISSION' => CanonicalAttendanceStatus::PERMISSION,
            'SICK' => CanonicalAttendanceStatus::SICK,
            'ABSENT' => CanonicalAttendanceStatus::ABSENT,
            'LATE' => CanonicalAttendanceStatus::LATE,
            'EXCUSED' => CanonicalAttendanceStatus::EXCUSED,
            default => throw new \InvalidArgumentException("Unsupported attendance status: {$status}"),
        };
    }
}
