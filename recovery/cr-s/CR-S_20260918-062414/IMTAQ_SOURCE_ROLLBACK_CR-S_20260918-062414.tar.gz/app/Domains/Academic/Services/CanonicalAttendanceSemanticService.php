<?php

namespace App\Domains\Academic\Services;

use App\Domains\Academic\Models\AcademicClass;
use App\Domains\Academic\Models\ClassSession;
use App\Domains\Academic\Models\SessionStudentParticipant;
use App\Domains\Academic\Semantics\CanonicalAttendanceStatusMapper;
use App\Domains\Academic\Semantics\Enums\AttendanceDataReadiness;
use App\Domains\Academic\Semantics\Enums\CanonicalAttendanceStatus;
use App\Domains\Academic\Semantics\Enums\EligibilityStatus;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

class CanonicalAttendanceSemanticService
{
    public function __construct(
        private readonly CanonicalAttendanceStatusMapper $statusMapper,
        private readonly JointAttendanceRosterBreakdownService $rosterBreakdown,
    ) {}

    public function sessionState(ClassSession $session, ?Carbon $now = null): string
    {
        $now ??= Carbon::now();

        if ($session->session_status === 'CANCELLED') {
            return 'CANCELLED';
        }
        if ($session->session_status === 'RESCHEDULED') {
            return 'RESCHEDULED_SOURCE';
        }
        if ($session->session_status === 'PLANNED' && $session->planned_start_at->isFuture($now)) {
            return 'PLANNED_FUTURE';
        }
        if ($session->session_status === 'PLANNED') {
            return 'PLANNED_HISTORICAL_WORK_QUEUE';
        }
        if ($session->session_status === 'COMPLETED') {
            return 'COMPLETED';
        }

        return 'OTHER';
    }

    /** @return array{status: EligibilityStatus, reason: ?string} */
    public function eligibility(SessionStudentParticipant $participant): array
    {
        $status = $participant->eligibility_status;
        if ($status === null) {
            $status = $participant->is_required ? EligibilityStatus::ELIGIBLE->value : EligibilityStatus::NON_ELIGIBLE->value;
        }

        return ['status' => EligibilityStatus::from($status), 'reason' => $participant->non_eligible_reason];
    }

    public function summarize(Collection $participants): array
    {
        $eligible = $participants->filter(fn (SessionStudentParticipant $participant): bool => $this->eligibility($participant)['status'] === EligibilityStatus::ELIGIBLE);
        $counts = collect(CanonicalAttendanceStatus::cases())->mapWithKeys(fn (CanonicalAttendanceStatus $status): array => [$status->value => 0])->all();
        $invalidStatuses = [];
        $resolved = 0;

        foreach ($eligible as $participant) {
            $attendance = $participant->attendance;
            if ($attendance?->workflow_status !== 'VALIDATED' || $attendance->attendance_status === null) {
                continue;
            }

            try {
                $status = $this->statusMapper->map($attendance->attendance_status);
            } catch (\InvalidArgumentException) {
                $invalidStatuses[] = $attendance->attendance_status;

                continue;
            }

            if ($status === null) {
                continue;
            }
            $counts[$status->value]++;
            $resolved++;
        }

        $eligibleCount = $eligible->count();
        $missing = $eligibleCount - $resolved;
        $completeness = $eligibleCount === 0 ? null : round(($resolved / $eligibleCount) * 100, 2);
        $readiness = $eligibleCount === 0
            ? AttendanceDataReadiness::NOT_STARTED
            : ($resolved === 0 ? AttendanceDataReadiness::NOT_STARTED : ($missing > 0 ? AttendanceDataReadiness::PARTIAL : AttendanceDataReadiness::COMPLETE));

        return [
            'eligible_opportunities' => $eligibleCount,
            'resolved_opportunities' => $resolved,
            'missing_opportunities' => $missing,
            'counts' => $counts,
            'completeness_rate' => $completeness,
            'data_status' => $readiness->value,
            'semantic_decision_required' => false,
            'invalid_statuses' => array_values(array_unique($invalidStatuses)),
            'official_attendance_rate' => $this->officialAttendanceRate($counts, $eligibleCount, $missing),
        ];
    }

    /**
     * Canonical live-period read model. Historical PLANNED sessions are returned
     * as an operational queue but never enter the official denominator.
     */
    public function forClassPeriod(AcademicClass $class, Carbon $from, Carbon $to): array
    {
        $sessions = ClassSession::query()
            ->where(fn ($query) => $query
                ->where('class_id', $class->id)
                ->orWhereHas('scopeGroups', fn ($scope) => $scope->where('class_id', $class->id)))
            ->whereBetween('planned_start_at', [$from, $to])
            ->with(['scopeGroups', 'studentParticipants' => fn ($query) => $query
                ->where('participant_status', 'EXPECTED')
                ->with(['attendance', 'student.classEnrollments'])])
            ->get();

        $completed = $sessions->filter(fn (ClassSession $session): bool => $this->sessionState($session) === 'COMPLETED');
        $participants = $completed->flatMap(function (ClassSession $session) use ($class) {
            if ($session->scopeGroups->count() <= 1) {
                return $session->studentParticipants->filter(fn (SessionStudentParticipant $participant): bool => $participant->is_required);
            }

            return $this->rosterBreakdown->forClass($session, $session->studentParticipants->filter(fn (SessionStudentParticipant $participant): bool => $participant->is_required), (string) $class->id);
        });

        $summary = $this->summarize($participants);
        $summary['completed_sessions'] = $completed->count();
        $summary['historical_planned_sessions'] = $sessions->filter(fn (ClassSession $session): bool => $this->sessionState($session) === 'PLANNED_HISTORICAL_WORK_QUEUE')->values()->map(fn (ClassSession $session): array => [
            'id' => (string) $session->id,
            'planned_start_at' => $session->planned_start_at?->toIso8601String(),
            'planned_end_at' => $session->planned_end_at?->toIso8601String(),
        ])->all();
        $summary['future_planned_sessions'] = $sessions->filter(fn (ClassSession $session): bool => $this->sessionState($session) === 'PLANNED_FUTURE')->count();
        $summary['cancelled_sessions'] = $sessions->filter(fn (ClassSession $session): bool => $this->sessionState($session) === 'CANCELLED')->count();
        $summary['rescheduled_sessions'] = $sessions->filter(fn (ClassSession $session): bool => $this->sessionState($session) === 'RESCHEDULED_SOURCE')->count();

        return $summary;
    }

    private function officialAttendanceRate(array $counts, int $eligible, int $missing): ?float
    {
        if ($eligible === 0 || $missing > 0) {
            return null;
        }

        return round((($counts[CanonicalAttendanceStatus::PRESENT->value] ?? 0) + ($counts[CanonicalAttendanceStatus::LATE->value] ?? 0)) / $eligible * 100, 2);
    }
}
